package user;

import books.BookList;
import operation.IOperation;

import java.util.Optional;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User:吴博
 * Date:2021 01 18
 * Time:22:43
 */
abstract public class User {
    //姓名
    protected String name;
    //要进行的操作
    protected IOperation[] operation;

    //显示菜单
    abstract public int menu();
    //根据用户的选择去进行相关操作
    public void doOperation(int choice, BookList bookList){
        operation[choice].work(bookList);
    }

}
