import books.BookList;
import user.AdminUser;
import user.NormalUser;
import user.User;

import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User:吴博
 * Date:2021 01 18
 * Time:22:42
 */
public class Main {
    public static void main(String[] args) {
        BookList bookList = new BookList();
        User user = login();
        while (true){
            int choice = user.menu();
            user.doOperation(choice,bookList);
        }
    }
    public static User login(){
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入您的姓名:");
        String name = sc.next();
        System.out.println("请输入您的身份(1 表示管理员, 0 表示普通用户):");
        int who = sc.nextInt();
        if (who == 1) {
            return new AdminUser(name);
        }
        return new NormalUser(name);
    }
}
