package operation;

import books.Book;
import books.BookList;

import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * 删除书
 * User:吴博
 * Date:2021 01 18
 * Time:23:02
 */
public class DelOperation implements IOperation{
    @Override
    public void work(BookList bookList) {
        System.out.println("删除书籍");
        Scanner sc = new Scanner(System.in);
        System.out.println("输入你想要删除的书籍的名字");
        String name = sc.nextLine();
        int i = 0;
        for (; i < bookList.getSize(); i++) {
            Book book = bookList.getBook(i);
            if(book.getName().equals(name))
                break;
        }
        if(i >= bookList.getSize()){
            System.out.println("没有要删除的这本书");
            return ;
        }
        int pos = i;
        for (; pos < bookList.getSize() - 1; pos++){
            Book book = bookList.getBook(pos + 1);
            bookList.setBook(pos,book);
        }
        int size = bookList.getSize() - 1;
        bookList.setSize(size);
        System.out.println("删除书籍完毕");
    }
}
