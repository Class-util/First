package operation;

import books.BookList;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * 继承该接口就对书架进行相关操作
 * User:吴博
 * Date:2021 01 18
 * Time:23:00
 */
public interface IOperation {
    void work(BookList bookList);
}
