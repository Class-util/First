package operation;

import books.BookList;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * 退出
 * User:吴博
 * Date:2021 01 18
 * Time:23:07
 */
public class ExitOperation implements IOperation {
    @Override
    public void work(BookList bookList) {
        System.out.println("退出系统");
        System.exit(1);
    }
}
