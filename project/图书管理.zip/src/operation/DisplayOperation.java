package operation;

import books.Book;
import books.BookList;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * 查阅书籍
 * User:吴博
 * Date:2021 01 18
 * Time:23:05
 */
public class DisplayOperation implements IOperation{
    @Override
    public void work(BookList bookList) {
        System.out.println("展示图书");
        for (int i = 0; i < bookList.getSize(); i++) {
            Book book = bookList.getBook(i);
            System.out.println(book);
        }
    }
}
