package operation;

import books.Book;
import books.BookList;

import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * 查找书
 * User:吴博
 * Date:2021 01 18
 * Time:23:03
 */
public class FindOperation implements IOperation{
    @Override
    public void work(BookList bookList) {
        System.out.println("查找书籍");
        Scanner sc = new Scanner(System.in);
        System.out.println("输入想要查找书籍的名字");
        String name = sc.nextLine();

        for (int i = 0; i < bookList.getSize(); i++) {
            Book book = bookList.getBook(i);
            if(book.getName().equals(name)){
                System.out.println("有这本书！");
                System.out.println(book);
                return ;
            }
        }
        System.out.println("没有找到这本书！");
    }
}
