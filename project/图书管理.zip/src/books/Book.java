package books;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * 书
 * User:吴博
 * Date:2021 01 18
 * Time:22:42
 */
public class Book {
    //书名
    private String name;
    //作者
    private String author;
    //价格
    private int price;
    //书的类型
    private String type;
    //书的借阅状态
    private boolean status;

    public Book(String name, String author, int price, String type) {
        this.name = name;
        this.author = author;
        this.price = price;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                ", type='" + type + '\'' +
                (status == false ? ", 未借阅 " : ", 已借阅 ") +
                '}';
    }
}
