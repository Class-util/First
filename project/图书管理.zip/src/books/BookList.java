package books;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * 书架
 * User:吴博
 * Date:2021 01 18
 * Time:22:43
 */
public class BookList {
    //Book数组用来存放书
    private Book[] books;
    //表示书的个数
    private int size;

    //初始化三本书
    public BookList() {
        this.books  = new Book[10];
        books[0] = new Book("三国演义", "罗贯中", 100, "小说");
        books[1] = new Book("水浒传", "施耐庵", 100, "小说");
        books[2] = new Book("西游记", "吴承恩", 100, "小说");
        this.size = 3;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    //获取书
    public Book getBook(int pos){
        return books[pos];
    }
    //设置书
    public void setBook(int pos, Book book){
        books[pos] = book;
    }
}
